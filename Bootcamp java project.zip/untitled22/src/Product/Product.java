package Product;


    public class Product {
        private String productId;
        private String productName;
        private String description;
        private double purchasePrice;
        private double sellingPrice;
        private int quantity;

        public Product(
                String productId,
                String productName,
                String description,
                double purchasePrice,
                double sellingPrice,
                int quantity
        ){
            this.productId = productId;
            this.productName = productName;
            this.description = description;
            this.purchasePrice = purchasePrice;
            this.sellingPrice=sellingPrice;
            this.quantity = quantity;
        }

        public Product() {

        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public String getProductName() {
            return productName;
        }

        public void setProductName(String productName) {
            this.productName = productName;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public double getPurchasePrice() {
            return purchasePrice;
        }

        public void setPurchasePrice(double purchasePrice) {
            this.purchasePrice = purchasePrice;
        }

        public double getSellingPrice() {
            return sellingPrice;
        }

        public void setSellingPrice(double sellingPrice) {
            this.sellingPrice = sellingPrice;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }



