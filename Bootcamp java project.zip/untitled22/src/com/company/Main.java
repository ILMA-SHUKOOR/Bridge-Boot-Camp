package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String mainExit="n";
        String subExit="n";
        int mainMenuSelector=0;
        int subMenuSelector=0;
        do{
            System.out.println("1) Manage product");
            System.out.println("2) Manage customers");
            System.out.println("3) Invoice Generation");
            System.out.println("4) Display all Invoices");
            System.out.println("5) Admin Tasks");
            System.out.println("6) Exit from the system");

            System.out.println("please select a number from your menu card:");
            mainMenuSelector=scanner.nextInt();

            switch(mainMenuSelector){
                //MANAGE PRODUCT SUB MENU
                case 1:

                    do{

                        System.out.println("1) Add product");
                        System.out.println("2) Delete product");
                        System.out.println("3) update product");
                        System.out.println("4) display a product details");
                        System.out.println("5) display all the product details");
                        System.out.println("6) back to main menu");

                        System.out.print("please enter the number of function : ");
                        subMenuSelector=scanner.nextInt();

                        switch(subMenuSelector){

                            case 1:
                                System.out.println("*** You selected Add Product Function ***");
                                //here should be adding product process
                                break;

                            case 2:
                                System.out.println("*** You selected Delete Product Function ***");
                                //here should be product deleting process
                                break;

                            case 3:
                                System.out.println("*** You selected update a Product Function ***");
                                //update product process
                                break;

                            case 4:
                                System.out.println("*** You selected Display a Product Function ***");
                                //display process
                                break;

                            case 5:
                                System.out.println("*** You selected Display All Products Function ***");
                                //display all product process
                                break;

                            case 6:
                                break;

                            default:
                                System.out.println("Invalid Input");
                                break;
                        }


                        System.out.println("Do you want to go Back to Product Menu?(press (y/n))");
                        subExit=scanner.next();
                    }while(subExit.equals("y"));

                    break;

                //manage customer sub menu
                case 2:

                    do{

                        System.out.println("1) Add customer");
                        System.out.println("2) Delete customer");
                        System.out.println("3) update customer");
                        System.out.println("4) display a customer details");
                        System.out.println("5) display all the customer details");
                        System.out.println("6) back to main menu");

                        System.out.print("please enter the number of function : ");
                        subMenuSelector=scanner.nextInt();

                        switch(subMenuSelector){

                            case 1:
                                System.out.println("*** You selected Add Customer Function ***");
                                //here should be adding Customer process
                                break;

                            case 2:
                                System.out.println("*** You selected Delete Customer Function ***");
                                //here should be Customer deleting process
                                break;

                            case 3:
                                System.out.println("*** You selected update a Customer Function ***");
                                //update Customer process
                                break;

                            case 4:
                                System.out.println("*** You selected Display a Customer Function ***");
                                //display process
                                break;

                            case 5:
                                System.out.println("*** You selected Display All Customer Function ***");
                                //display all Customer process
                                break;

                            case 6:
                                break;

                            default:
                                System.out.println("Invalid Input");
                                break;
                        }

                        System.out.println("Do you want to go Back to Customer Menu?(press (y/n))");
                        subExit=scanner.next();
                    }while(subExit.equals("y"));

                    break;

                //invoice generation process
                case 3:
                    System.out.println("here Start the invoice generation process");

                    break;

                //display all generated invoices
                case 4:
                    System.out.println("Display all the generated Invoices");

                    break;

                //display all the activities have done before
                case 5:
                    System.out.println("Display all the Admin tasks");

                    break;

                case 6:
                    break;

                default :
                    System.out.println("Invalid Input");

                    break;


            }
            System.out.println("Do you want to go Back to Main Menu?(press (y/n))");
            mainExit=scanner.next();

        }while(mainExit.equals("y"));

        System.out.println("Thank you!");

    }
}
