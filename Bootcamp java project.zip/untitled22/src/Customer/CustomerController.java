package Customer;


import DBConnection.DBConnector;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CustomerController {
    //addCustomer
    public static int AddCustomer(Customer cus) throws ClassNotFoundException, SQLException {
        Connection con = DBConnector.getConnection();

        String query = "INSERT INTO customers(customerId,customerName,eMail,address,contactNumber,dateOfBirth,gender) " +
                "VALUES('"+ cus.getCustomerId() +"','"+ cus.getCustomerName() +"','"+ cus.geteMail() +"','"+ cus.getAddress() +"','"+cus.getContactNo()+"','"+ cus.getDateOfBirth() +"','"+ cus.getGender() +"')";

        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //customerUpdate
    public static int UpdateCustomer(String cusID, Customer cus) throws SQLException, ClassNotFoundException {
        Connection con = DBConnector.getConnection();

        String query = "UPDATE customers SET(customerName='"+ cus.getCustomerId() +"',eMail='"+ cus.getCustomerId() +"',address='"+ cus.getCustomerId() +"',contactNumber='"+ cus.getCustomerId() +"',dateOfBirth='"+ cus.getCustomerId() +"',gender='"+ cus.getCustomerId() +"') WHERE customerId='"+ cusID +"'";
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //customerDelete
    public static int DeleteCustomer(String cusID) throws SQLException, ClassNotFoundException{
        Connection con = DBConnector.getConnection();

        String query = "DELETE FROM customers WHERE customerId="+cusID;
        Statement stmt = con.createStatement();

        return stmt.executeUpdate(query);
    }

    //get customer
    public static Customer getCustomer(String cusID) throws ClassNotFoundException, SQLException {
        Connection con = DBConnector.getConnection();

        Customer cus = null;

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM customers WHERE customerId="+cusID;
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String customerId = rs.getString("customerId");
            String customerName = rs.getString("customerName");
            String eMail = rs.getString("eMail");
            String address = rs.getString("address");
            String contactNumber = rs.getString("contactNumber");
            String dateOfBirth = rs.getString("dateOfBirth");
            String gender = rs.getString("gender");

            cus = new Customer(customerId, customerName, eMail, address, contactNumber, dateOfBirth, gender);
        }
        return cus;
    }

    //get customers
    public static ArrayList getCustomers() throws ClassNotFoundException, SQLException {
        Connection con = DBConnector.getConnection();
        ArrayList customerArray = new ArrayList();

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM customers";
        ResultSet rs = stmt.executeQuery(query);

        while (rs.next()){
            String customerId = rs.getString("customerId");
            String customerName = rs.getString("customerName");
            String eMail = rs.getString("eMail");
            String address = rs.getString("address");
            String contactNumber = rs.getString("contactNumber");
            String dateOfBirth = rs.getString("dateOfBirth");
            String gender = rs.getString("gender");

            Customer cus  = new Customer(customerId, customerName, eMail, address, contactNumber, dateOfBirth, gender);
            customerArray.add(cus);
        }
        return customerArray;

}
    }






